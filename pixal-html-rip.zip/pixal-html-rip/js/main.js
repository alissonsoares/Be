(function($) {
    "use strict";
/*--
    Menu Sticky
-----------------------------------*/
var $window = $(window);
$window.on('scroll', function() {
	var scroll = $window.scrollTop();
	if (scroll < 300) {
		$(".sticker").removeClass("stick");
	}else{
		$(".sticker").addClass("stick");
	}
});
/*--
    Mobile Menu
-----------------------------------*/
$('.main-menu nav').meanmenu({
	meanScreenWidth: '767',
	meanMenuContainer: '.mobile-menu',
	meanMenuClose: '<span class="mmenu-open close"></span>',
	meanMenuOpen: '<span class="mmenu-open"></span>',
	meanRevealPosition: 'right',
	meanMenuCloseSize: '30px',
});
/*--
	Home Slick Slider
-----------------------------------*/
/*-- Text Slider --*/
$('.hero-slider').slick({
    arrows: false,
    autoplay: true,
    autoplaySpeed: 5000,
    dots: true,
    slidesToShow: 1,
});
/*--
    Testimonial Slider
-----------------------------------*/
$('.testimonial-slider').slick({
    arrows: false,
    autoplay: true,
    slidesToShow: 1,
});
$('.testimonial-slider-2').slick({
    centerMode: true,
    centerPadding: '0px',
    speed: 700,
    slidesToShow: 3,
    swipeToSlide: true,
    prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-long-arrow-left"></i></button>',
    nextArrow: '<button type="button" class="slick-next"><i class="fa fa-long-arrow-right"></i></button>',
    responsive: [
        {
            breakpoint: 1169,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
                centerMode: false,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
                centerMode: false,
            }
        },
    ]
});
/*--
    Portfolio Slider
-----------------------------------*/
$('.portfolio-slider').slick({
    arrows: false,
    speed: 700,
    slidesToShow: 5,
    swipeToSlide: true,
    responsive: [
        {
            breakpoint: 1400,
            settings: {
                slidesToShow: 4,
            }
        },
        {
            breakpoint: 1169,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
            }
        },
    ]
});
$('.portfolio-slider-3').slick({
    arrows: false,
    speed: 700,
    slidesToShow: 3,
    swipeToSlide: true,
    responsive: [
        {
            breakpoint: 1169,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
            }
        },
    ]
});
/*--
    Team Slider
-----------------------------------*/
$('.team-slider').slick({
    arrows: false,
    speed: 700,
    slidesToShow: 5,
    swipeToSlide: true,
    responsive: [
        {
            breakpoint: 1400,
            settings: {
                slidesToShow: 4,
            }
        },
        {
            breakpoint: 1169,
            settings: {
                slidesToShow: 3,
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
            }
        },
    ]
});
/*--
	Counter UP
-----------------------------------*/
$('.counter').counterUp({
    delay: 20,
    time: 3000
});
/*--
	Isotop with ImagesLoaded
-----------------------------------*/
var portfolioFilter = $('.portfolio-filter');
var portfolioGrid = $('.portfolio-grid');
/*-- Images Loaded --*/
portfolioGrid.imagesLoaded( function() {
    /*-- Filter List --*/
    portfolioFilter.on( 'click', 'button', function() {
        portfolioFilter.find('button').removeClass('active');
        $(this).addClass('active');
        var filterValue = $(this).attr('data-filter');
        portfolioGrid.isotope({ filter: filterValue });
    });
    /*-- Filter Grid --*/
    portfolioGrid.isotope({
      itemSelector: '.portfolio-item',
      masonry: {
        columnWidth: '.portfolio-item',
      }
    });
});
///*-- 
//    ScrollUp
//-----------------------------------*/
//$.scrollUp({
//    scrollText: '<i class="fa fa-angle-up"></i>',
//    easingType: 'linear',
//    scrollSpeed: 900,
//    animation: 'fade'
//});
/*-- Magnific Video Popup --*/
var videoPopup = $('.video-popup');
videoPopup.magnificPopup({
	type: 'iframe',
	mainClass: 'mfp-fade',
	removalDelay: 160,
	preloader: false,
	zoom: {
		enabled: true,
	}
});
/*-- 
    WOW
-----------------------------------*/
new WOW().init();

})(jQuery);



